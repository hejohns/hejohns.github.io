---
layout: page
title: reviews
---
This is supposed to be where I put either
book reviews
or notes, but it has yet to happen.

Shoutout to kaobook.

{% pdf {{ "/files/sample.pdf" }} %}
