---
layout: post
title: coordinating processes
date: 2023-10-29
---
This has to be a solved problem?!

[repo](https://github.com/hejohns/systemp)

