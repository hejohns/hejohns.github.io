---
layout: post
title: chili oil
date: 2023-05-02
---
since I always manage to forget something so simple:
- take the thai chili or equivalent
- remove stem, and remove tip as it's prone to burning
- the seeds burn slower than the flesh, so
- cut in half lengthwise
- remove the seeds and put them in a spoon
- cut the flesh into quarters or some sort of strip
    - if the pieces are too small, they tend to burn
    - if the pieces are too large, it's a waste of pepper
- heat neutral oil in the smallest saucepan
- seeds in first, dump the spoon
- wait a bit, then fresh in
- high heat quickly, then immediately off to prevent burning
