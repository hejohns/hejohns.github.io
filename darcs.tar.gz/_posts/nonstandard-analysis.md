---
layout: post
title: shelving studying nonstandard analysis
date: 2023-05-07
---

(personal record keeping)

I've whiled away my chances last semester to take a close look at nonstandard analysis while I had the time,
and now I can no longer set aside focus for it in good conscience.
With pressing matters of higher priority, I formally declare, with great regret,
an indefinite hiatus of this project, marked by the returning of Goldblatt's book.

It was an excellent time to study nonstandard analysis,
on the tails of the excellent model theory class and continuous logic seminar,
but the model theoretic background seems low enough that picking Goldblatt's book back up should be smooth.

Alas. One day. One day.
