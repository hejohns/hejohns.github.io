---
layout: post
title: my gsi application videos
date: 2023-04-09
---
- toc
{:toc}

## ENGR 101 (F23)
**outcome**: rejected.
But they also didn't look at the video[^1].

[^1]: I dumb and got "private" and "unlisted" backwards.

<iframe width="560" height="315" src="https://www.youtube.com/embed/Cd9Tq7s_BhQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

{% pdf {{ "/files/101-gsi-application.pdf" }} %}
## EECS 376 (F23)
**outcome**: rejected. No response.
### too long version
<iframe width="560" height="315" src="https://www.youtube.com/embed/UyT7Oa6Gxdc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
### actual submission
<iframe width="560" height="315" src="https://www.youtube.com/embed/2S60JnY5zus" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

## EECS 482 (no application video)
**outcome**: F23 482 GSI.

In the end, I found a job as a 482 GSI, not by making a good video
(not that 482 asks for videos),
but by responding to an email solicitation for a 482 summer (23 Sp+Su) IA
with lightning reflexes.

The same instructor over the summer is teaching the fall term now,
so I've stayed on as a GSI.

For the IA position, it helped that I cleared my schedule back when I took 482
and got good grades.
And that I had IA 'd before (for 490).

There were some other external factors, but things worked out in the end.
I am grateful for the support of a particular faculty member in this escapade.
